package pl.mariuszlyszczarz.BusTicketsBookingSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusTicketsBookingSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusTicketsBookingSpringBootApplication.class, args);
	}
}
