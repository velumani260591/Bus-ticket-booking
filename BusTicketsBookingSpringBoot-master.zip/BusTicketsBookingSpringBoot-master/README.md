# BusTicketsBookingSpringBoot
Tickets booking system for the bus on Spring Boot.

The technologies used in the project:
Database,
Spring Boot,
Hibernate,
Java,
HTML,
CSS,
JavaScript,
Bootstrap,
Thymeleaf
Lombok


I invite you to test: 77.55.192.13:8095/index
